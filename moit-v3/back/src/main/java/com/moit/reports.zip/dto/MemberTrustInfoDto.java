package com.moit.reports.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class MemberTrustInfoDto {	// 신고당한 회원 정보, 신뢰도/뱃지 조회 DTO
	// MEMBERS
	private Long targetMemberId;	// 신고당한 회원 id
	private String targetNickname;	// 신고당한 회원 닉네임	MemberRepository
	
	// MEMBER_INFO
	private Integer trustScore;		// 신뢰도 점수			MemberInfoRepository
	
	// MEMBER_REPORT_STATUS
	private Long reportStatusId;	//	1		/	2		/	3
	private String statusCode;		// 'ACTIVE' / 'WARNING' / 'DANGER'
	private String statusName;		// '정상'		/ '주의'		/ '위험'
}
